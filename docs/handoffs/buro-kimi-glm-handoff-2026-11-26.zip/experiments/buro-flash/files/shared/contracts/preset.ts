import type { ReviewSettings } from './review.ts';

/** Explicit launch settings copied from a preset into ordinary run options. */
export interface PresetOptions {
  modelId?: string;
  instructions?: string;
  review?: ReviewSettings;
}

/** A named, editable launch configuration; it is not an agent role or a run reference. */
export interface LaunchPreset {
  id: string;
  name: string;
  options: PresetOptions;
}

/** Expected inability to save a preset is returned to the caller. */
export interface PresetResult {
  ok: boolean;
  preset?: LaunchPreset;
  error?: string;
}
