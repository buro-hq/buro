import type { RecordStore } from '../storage/record-store.ts';
import type { LaunchPreset, PresetOptions, PresetResult } from '#shared/contracts';

/** Owns named launch configurations, separately from the runs that copied their options. */
export interface PresetStore extends RecordStore<LaunchPreset> {}

/** Editable launch presets; a run keeps the options it started with. */
export interface Presets {
  /** Lists saved presets in insertion order. */
  list(): Promise<LaunchPreset[]>;
  /** Returns a saved preset or undefined. */
  get(input: { id: string }): Promise<LaunchPreset | undefined>;
  /** Creates a preset with a generated id, or updates an existing one. */
  save(input: { id?: string; name: string; options: PresetOptions }): Promise<PresetResult>;
  /** Removes one preset without changing runs or application defaults. */
  delete(input: { id: string }): Promise<void>;
}
