import { randomUUID } from 'node:crypto';
import type { Notifications } from '../events/notifications.ts';
import type { Presets, PresetStore } from './preset.ts';
import type { LaunchPreset, PresetOptions, PresetResult } from '#shared/contracts';

/** Owns launch configurations independently of the runs that copied their options. */
export class PresetService implements Presets {
  private store: PresetStore;
  private events: Notifications;

  /** Connects preset storage and change notifications. */
  constructor(input: { store: PresetStore; events: Notifications }) {
    this.store = input.store;
    this.events = input.events;
  }

  /** Lists saved presets without assigning special meaning to their names. */
  async list(): Promise<LaunchPreset[]> {
    return this.store.list();
  }

  /** Reads one saved preset. */
  async get(input: { id: string }): Promise<LaunchPreset | undefined> {
    return this.store.get(input.id);
  }

  /** Creates a preset or updates a saved one; runs keep the options they copied earlier. */
  async save(input: { id?: string; name: string; options: PresetOptions }): Promise<PresetResult> {
    if (input.id !== undefined) {
      const saved = await this.store.get(input.id);
      if (!saved)
        return { ok: false, error: 'Preset not found.' };
    }

    const preset: LaunchPreset = {
      id: input.id ?? randomUUID(),
      name: input.name,
      options: structuredClone(input.options),
    };
    await this.store.save(preset);
    this.events.publish({
      type: 'preset.saved',
      data: preset,
    });
    return { ok: true, preset };
  }

  /** Removes one preset without changing historical runs or application defaults. */
  async delete(input: { id: string }): Promise<void> {
    await this.store.delete(input.id);
    this.events.publish({
      type: 'preset.deleted',
      data: input,
    });
  }
}
