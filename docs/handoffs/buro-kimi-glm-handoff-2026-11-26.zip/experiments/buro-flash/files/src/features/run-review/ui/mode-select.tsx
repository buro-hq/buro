import { Select } from '@mantine/core';
import type { ReactElement } from 'react';
import type { ReviewSettings } from '#shared/contracts';
import { t } from '@/i18n/index.ts';

/** Tri-state review mode: unset keeps the application default, clearing removes only the mode. */
export interface ReviewModeSelectProps {
  value: ReviewSettings;
  onChange(value: ReviewSettings): void;
}

// Clearing the mode keeps the participant and round configuration; the ignored key is intentionally unused.
const withoutMode = ({ enabled: _mode, ...review }: ReviewSettings): ReviewSettings => review;

/** Selects the explicit review override without merging application defaults in the UI. */
export const ReviewModeSelect = ({ value, onChange }: ReviewModeSelectProps): ReactElement => (
  <Select
    label={t('Automatic team review')}
    placeholder={t('Application default')}
    clearable
    value={value.enabled === undefined ? null : value.enabled ? 'enabled' : 'disabled'}
    onChange={(mode) => onChange(mode === null
      ? withoutMode(value)
      : { ...withoutMode(value), enabled: mode === 'enabled' })}
    data={[
      { value: 'enabled', label: t('Enabled') },
      { value: 'disabled', label: t('Disabled') },
    ]}
  />
);
