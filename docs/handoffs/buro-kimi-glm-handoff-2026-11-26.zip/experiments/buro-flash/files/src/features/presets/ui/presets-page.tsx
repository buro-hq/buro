import { Button, Group, Paper, Stack, Text } from '@mantine/core';
import { useState, type ReactElement } from 'react';
import type { LaunchPreset, ReviewSettings } from '#shared/contracts';
import { t } from '@/i18n/index.ts';
import { Panel, ErrorNotice, QueryFeedback } from '@/shared/ui';
import { useOperation } from '@/shared/lib';
import { useApplication, useApiQuery } from '@/data/application.tsx';
import { PresetEditor } from './preset-editor.tsx';

/** Saved launch settings are editable data; a run copies the options it starts with. */
export const PresetsPage = (): ReactElement => {
  const { client } = useApplication();
  const presets = useApiQuery('presets.list', {});
  const models = useApiQuery('models.list', {});
  const action = useOperation();
  const [editor, setEditor] = useState<{ preset?: LaunchPreset }>();
  const modelName = (modelId?: string): string => {
    if (!modelId)
      return t('Application default');

    return models.data?.find((model) => model.id === modelId)?.name ?? modelId;
  };
  const reviewState = (review?: ReviewSettings): string => {
    if (review?.enabled === undefined)
      return t('Application default');

    return review.enabled ? t('Enabled') : t('Disabled');
  };
  return (
    <Panel
      title={t('Launch presets')}
      description={t('Saved launch settings. Selecting one copies its options into the goal launch controls.')}
      aside={<Button onClick={() => setEditor({})}>{t('New preset')}</Button>}
    >
      <Stack>
        <QueryFeedback loading={presets.loading} error={presets.error} />
        <ErrorNotice error={action.error} />
        {presets.data?.length === 0 && <Text c="dimmed">{t('No saved presets yet')}</Text>}
        {presets.data?.map((preset) => (
          <Paper key={preset.id} withBorder p="md">
            <Stack gap="sm">
              <Text fw={600}>{preset.name}</Text>
              <Text size="sm">
                {t('Model')}: {modelName(preset.options.modelId)}
              </Text>
              <Text size="sm">
                {t('Automatic team review')}: {reviewState(preset.options.review)}
              </Text>
              {preset.options.review?.participants?.map((participant, index) => (
                <Text key={index} size="xs" c="dimmed">
                  {participant.name}
                </Text>
              ))}
              <Group>
                <Button
                  variant="default"
                  onClick={() => setEditor({
                    preset,
                  })}
                >
                  {t('Edit')}
                </Button>
                <Button
                  variant="subtle"
                  color="red"
                  onClick={() =>
                    void action.perform(async () => {
                      await client.call('presets.delete', {
                        id: preset.id,
                      });
                      return { ok: true };
                    })}
                >
                  {t('Delete')}
                </Button>
              </Group>
            </Stack>
          </Paper>
        ))}
      </Stack>
      {editor && (
        <PresetEditor
          key={editor.preset?.id ?? 'new'}
          preset={editor.preset}
          models={models.data ?? []}
          onClose={() => setEditor(undefined)}
        />
      )}
    </Panel>
  );
};
