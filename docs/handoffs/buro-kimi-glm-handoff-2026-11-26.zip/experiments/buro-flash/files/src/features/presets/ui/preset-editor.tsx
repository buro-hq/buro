import { Button, Checkbox, Group, Modal, Select, Stack, Textarea, TextInput } from '@mantine/core';
import { useState, type ReactElement } from 'react';
import type { LaunchPreset, PresetOptions, ReviewSettings } from '#shared/contracts';
import type { AvailableModel } from '../../../../agent/contracts/model.ts';
import { t } from '@/i18n/index.ts';
import { ErrorNotice } from '@/shared/ui';
import { useOperation } from '@/shared/lib';
import { useApplication } from '@/data/application.tsx';
import { ReviewEditor, ReviewModeSelect } from '@/features/run-review';

/** The values of one saved launch configuration being edited. */
export interface PresetEditorProps {
  preset?: LaunchPreset;
  models: AvailableModel[];
  onClose(): void;
}

/** Creates or updates one saved launch configuration; runs never reference it. */
export const PresetEditor = ({ preset, models, onClose }: PresetEditorProps): ReactElement => {
  const { client } = useApplication();
  const action = useOperation();
  const [name, setName] = useState(preset?.name ?? '');
  const [modelId, setModelId] = useState<string | null>(preset?.options.modelId ?? null);
  const [instructions, setInstructions] = useState(preset?.options.instructions);
  const [override, setOverride] = useState(preset?.options.instructions !== undefined);
  const [review, setReview] = useState<ReviewSettings>(preset?.options.review ?? {});
  const save = async (): Promise<void> => {
    const options: PresetOptions = {
      ...(modelId ? { modelId } : {}),
      ...(override ? { instructions: instructions ?? '' } : {}),
      ...(Object.keys(review).length ? { review } : {}),
    };
    const result = await action.perform(async () => {
      const saved = await client.call('presets.save', {
        id: preset?.id,
        name,
        options,
      });
      return { ok: saved.ok, error: saved.error };
    });
    if (result.ok)
      onClose();
  };
  return (
    <Modal opened onClose={onClose} title={t('Launch preset')} size="lg">
      <Stack>
        <TextInput
          label={t('Preset name')}
          value={name}
          onChange={(event) => setName(event.currentTarget.value)}
        />
        <Select
          label={t('Model')}
          placeholder={t('Application default')}
          clearable
          value={modelId}
          data={models.map((model) => ({ value: model.id, label: model.name ?? model.id }))}
          onChange={setModelId}
        />
        <Checkbox
          label={t('Override instructions')}
          description={t('Unchecked keeps the application default instructions. An empty text is an explicit empty override.')}
          checked={override}
          onChange={(event) => setOverride(event.currentTarget.checked)}
        />
        {override && (
          <Textarea
            label={t('Instructions')}
            value={instructions ?? ''}
            onChange={(event) => setInstructions(event.currentTarget.value)}
            autosize
            minRows={6}
          />
        )}
        <ReviewModeSelect value={review} onChange={setReview} />
        {review.enabled === true && (
          <ReviewEditor value={review} models={models} onChange={setReview} />
        )}
        <ErrorNotice error={action.error} />
        <Group justify="end">
          <Button variant="default" onClick={onClose}>
            {t('Cancel')}
          </Button>
          <Button loading={action.busy} onClick={() => void save()}>
            {t('Save')}
          </Button>
        </Group>
      </Stack>
    </Modal>
  );
};
