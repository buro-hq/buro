import {
  Button,
  Group,
  Paper,
  Select,
  Stack,
  Text,
  Textarea,
  Checkbox,
  Collapse,
} from '@mantine/core';
import { useState, type ReactElement } from 'react';
import type { Task } from '../../../modules/tasks/task.ts';
import type { RunOptions } from '../../../modules/runs/run.ts';
import { useApplication, useApiQuery } from '../../data/application.tsx';
import { t } from '../../i18n/index.ts';
import { Panel, ErrorNotice, QueryFeedback } from '@/shared/ui';
import { useOperation } from '@/shared/lib';
import { TaskEditor } from './TaskEditor.tsx';
import { ReviewEditor, ReviewModeSelect } from '@/features/run-review';
import type { PresetOptions, ReviewSettings } from '#shared/contracts';

/** Owns task editing and explicit run options; it never reconstructs server state from events. */
export const TasksPage = (input: { projectId: string; onRun(id: string): void }): ReactElement => {
  const { client } = useApplication();
  const tasks = useApiQuery('tasks.list', {
    projectId: input.projectId,
  });
  const models = useApiQuery('models.list', {});
  const presets = useApiQuery('presets.list', {});
  const settings = useApiQuery('settings.get', {});
  const action = useOperation();
  const [editor, setEditor] = useState<{ task?: Task }>();
  const [advanced, setAdvanced] = useState(false);
  const [presetId, setPresetId] = useState<string | null>(null);
  const [options, setOptions] = useState<PresetOptions>({});
  const [readOnly, setReadOnly] = useState(false);
  const selectedPreset = presets.data?.find((candidate) => candidate.id === presetId);
  const review = options.review ?? {};
  const changePreset = (id: string | null): void => {
    setPresetId(id);
    const preset = presets.data?.find((candidate) => candidate.id === id);
    if (preset)
      setOptions(structuredClone(preset.options));
  };
  const changeReview = (next: ReviewSettings): void => {
    const hasOverride = Object.keys(next).length > 0;
    setOptions({
      ...options,
      review: hasOverride ? next : undefined,
    });
  };
  const start = async (taskId: string): Promise<void> => {
    const runOptions: RunOptions = { ...options, ...(readOnly ? { readOnly: true } : {}) };
    const result = await action.perform(async () => {
      const started = await client.call('runs.start', {
        taskId,
        options: runOptions,
      });
      return { ok: started.ok, value: started.run, error: started.error };
    });
    if (result.value)
      input.onRun(result.value.id);
  };
  return (
    <Panel
      title={t('Goals')}
      description={t('Describe the result. The agent chooses its tools and collaborators.')}
      aside={<Button onClick={() => setEditor({})}>{t('New goal')}</Button>}
    >
      <Stack>
        <Group>
          <Select
            label={t('Launch preset')}
            placeholder={t('No preset')}
            clearable
            value={selectedPreset ? presetId : null}
            onChange={changePreset}
            data={(presets.data ?? []).map((preset) => ({ value: preset.id, label: preset.name }))}
            miw={240}
          />
          <Select
            label={t('Model')}
            placeholder={t('Application default')}
            clearable
            value={options.modelId ?? null}
            onChange={(modelId) => setOptions({
              ...options,
              modelId: modelId ?? undefined,
            })}
            data={(models.data ?? []).map((model) => ({ value: model.id, label: model.name }))}
            miw={240}
          />
          <Button variant="subtle" mt="auto" onClick={() => setAdvanced((value) => !value)}>
            {t('Run options')}
          </Button>
        </Group>
        <QueryFeedback loading={presets.loading} error={presets.error} />
        <Collapse in={advanced}>
          <Stack>
            <Textarea
              label={t('Instructions override')}
              description={t('Optional')}
              value={options.instructions ?? ''}
              onChange={(event) => setOptions({
                ...options,
                instructions: event.currentTarget.value || undefined,
              })}
              autosize
              minRows={3}
            />
            <Checkbox
              label={t('Read-only workspace')}
              checked={readOnly}
              onChange={(event) => setReadOnly(event.currentTarget.checked)}
            />
            <ReviewModeSelect value={review} onChange={changeReview} />
            {review.enabled === true && (
              <ReviewEditor
                value={{
                  ...settings.data?.review,
                  ...review,
                  enabled: true,
                }}
                models={models.data ?? []}
                onChange={changeReview}
              />
            )}
          </Stack>
        </Collapse>
        <ErrorNotice error={action.error} />
        <QueryFeedback loading={tasks.loading} error={tasks.error} />
        {tasks.data?.length === 0 && <Text c="dimmed">{t('No goals yet')}</Text>}
        {tasks.data
          ?.slice()
          .reverse()
          .map((task) => (
            <Paper key={task.id} withBorder p="md">
              <Stack gap="sm">
                <Text fw={600}>{task.title}</Text>
                <Text size="sm" style={{ whiteSpace: 'pre-wrap' }}>
                  {task.description}
                </Text>
                <Group>
                  <Button loading={action.busy} onClick={() => void start(task.id)}>
                    {t('Start run')}
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => setEditor({
                      task,
                    })}
                  >
                    {t('Edit')}
                  </Button>
                  <Button
                    variant="subtle"
                    color="red"
                    onClick={() =>
                      void action.perform(async () => {
                        await client.call('tasks.delete', {
                          id: task.id,
                        });
                        return { ok: true };
                      })}
                  >
                    {t('Delete')}
                  </Button>
                </Group>
              </Stack>
            </Paper>
          ))}
      </Stack>
      {editor && (
        <TaskEditor
          key={editor.task?.id ?? 'new'}
          projectId={input.projectId}
          task={editor.task}
          opened
          onClose={() => setEditor(undefined)}
          onSaved={(task, shouldStart) => {
            setEditor(undefined);
            if (shouldStart)
              void start(task.id);
          }}
        />
      )}
    </Panel>
  );
};
