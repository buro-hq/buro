import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { chromium, expect } from '@playwright/test';
import { createServer } from 'vite';
import { createApplication } from '../modules/application/create-application.ts';
import { startApiServer } from '../modules/api/server.ts';
import { localPort } from './fixtures/local-port.ts';
import type { PresetOptions } from '#shared/contracts';

const exec = promisify(execFile);

test(
  'launch presets are created, selected, copied into a run and deleted from the browser UI',
  {
    timeout: 90000,
  },
  async (t) => {
    const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'buro-presets-ui-'));
    const root = path.join(directory, 'source');
    await fs.mkdir(root);
    await exec('git', ['init', '-q', root]);
    await fs.writeFile(path.join(root, 'README.md'), 'Initial\n');
    await exec('git', ['add', '.'], {
      cwd: root,
    });
    await exec(
      'git',
      [
        '-c',
        'core.hooksPath=/dev/null',
        '-c',
        'commit.gpgsign=false',
        '-c',
        'user.name=Test',
        '-c',
        'user.email=test@example.invalid',
        'commit',
        '-qm',
        'Initial',
      ],
      {
        cwd: root,
      },
    );
    const app = await createApplication({
      directory: path.join(directory, 'state'),
      transports: [
        {
          id: 'fixture',
          create({ configuration }) {
            return {
              id: configuration.id,
              revision: configuration.revision,
              async complete(request) {
                return {
                  model: 'fixture',
                  finish: 'stop',
                  message: {
                    role: 'assistant',
                    content: request.schema
                      ? JSON.stringify({
                          summary: 'Preset review completed.',
                          findings: [],
                        })
                      : 'Preset run complete.',
                  },
                };
              },
            };
          },
        },
      ],
    });
    t.after(() => app.close());
    const model = await app.modelConfigurations.save({
      configuration: {
        name: 'Fixture model',
        transport: 'fixture',
        model: 'fixture',
      },
      default: true,
    });
    assert.equal(model.ok, true);
    const modelId = model.configuration!.id;
    const defaults = await app.settings.get();
    const api = await startApiServer({
      application: app,
      token: 'test-presets-token',
      port: 0,
    });
    t.after(() => api.close());
    const vite = await createServer({
      cacheDir: path.join(directory, 'vite-cache'),
      server: {
        host: '127.0.0.1',
        port: await localPort(),
        open: false,
      },
      plugins: [
        {
          name: 'presets-client-test-entry',
          configureServer(server) {
            server.middlewares.use(async (request, response, next) => {
              if (request.url?.split('?')[0] !== '/__presets.html')
                return next();

              try {
                const html = await server.transformIndexHtml(
                  '/__presets.html',
                  `<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"></head><body><div id="root"></div><script type="module">
          import '@mantine/core/styles.css'; import '/src/styles.css'; import '/src/styles/features.css';
          import React from 'react'; import {createRoot} from 'react-dom/client'; import {Application} from '/src/Application.tsx';
          import {AppearanceProvider} from '/src/theme/AppearanceProvider.tsx'; import {ApplicationProvider} from '/src/data/application.tsx';
          createRoot(document.getElementById('root')).render(React.createElement(AppearanceProvider,null,React.createElement(ApplicationProvider,{url:'ws://127.0.0.1:${api.port}'},React.createElement(Application))));
        </script></body></html>`,
                );
                response.setHeader('Content-Type', 'text/html');
                response.end(html);
              } catch (error) {
                next(error);
              }
            });
          },
        },
      ],
    });
    t.after(() => vite.close());
    await vite.listen();
    const address = vite.httpServer!.address();
    assert.ok(address && typeof address !== 'string');
    const browser = await chromium.launch({
      headless: true,
    });
    t.after(() => browser.close());
    // Node runs after hooks in registration order, so the temporary state is removed only after the application, API and Vite server close.
    t.after(() => fs.rm(directory, {
      recursive: true,
      force: true,
    }));
    const page = await browser.newPage({
      viewport: {
        width: 1440,
        height: 1000,
      },
    });
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    await page.goto(`http://127.0.0.1:${address.port}/__presets.html#buro-token=test-presets-token`);
    await page.locator('main').getByRole('button', {
      name: 'Connect project',
      exact: true,
    }).click();
    await page.getByRole('textbox', {
      name: 'Project directory',
      exact: true,
    }).fill(root);
    await page.getByRole('dialog').getByRole('button', {
      name: 'Connect project',
      exact: true,
    }).click();
    await page.locator('.sidebar').getByRole('button', {
      name: 'Goals',
      exact: true,
    }).click();
    await page.getByRole('button', {
      name: 'New goal',
      exact: true,
    }).click();
    await page.getByRole('textbox', {
      name: 'What should we achieve?',
      exact: true,
    }).fill('Preset goal');
    await page.getByRole('textbox', {
      name: 'Context and expected result',
      exact: true,
    }).fill('Describe the preset launch.');
    await page.getByRole('button', {
      name: 'Save goal',
      exact: true,
    }).click();
    await page.locator('.sidebar').getByRole('button', {
      name: 'Presets',
      exact: true,
    }).click();
    await expect(page.getByText('No saved presets yet', {
      exact: true,
    })).toBeVisible();
    await page.getByRole('button', {
      name: 'New preset',
      exact: true,
    }).click();
    const editor = page.getByRole('dialog');
    await editor.getByRole('textbox', {
      name: 'Preset name',
      exact: true,
    }).fill('Careful launch');
    await editor.getByRole('textbox', {
      name: 'Model',
      exact: true,
    }).click();
    await expect(page.getByRole('option', {
      name: 'Fixture model',
      exact: true,
    })).toBeVisible();
    await page.getByRole('option', {
      name: 'Fixture model',
      exact: true,
    }).click();
    await editor.getByLabel('Override instructions', {
      exact: true,
    }).check();
    await editor.getByLabel('Instructions', {
      exact: true,
    }).fill('Preset instructions');
    await editor.getByRole('textbox', {
      name: 'Automatic team review',
      exact: true,
    }).click();
    await expect(page.getByRole('option', {
      name: 'Enabled',
      exact: true,
    })).toBeVisible();
    await page.getByRole('option', {
      name: 'Enabled',
      exact: true,
    }).click();
    await editor.getByRole('button', {
      name: 'Add reviewer',
      exact: true,
    }).click();
    await editor.getByLabel('Reviewer name', {
      exact: true,
    }).fill('Preset reviewer');
    await editor.getByRole('button', {
      name: 'Save',
      exact: true,
    }).click();
    // The saved preset must appear through the preset notification only; never reload the page.
    await expect(page.getByText('Careful launch', {
      exact: true,
    })).toBeVisible();
    await expect(page.getByText('Preset reviewer', {
      exact: true,
    })).toBeVisible();
    await page.locator('.sidebar').getByRole('button', {
      name: 'Goals',
      exact: true,
    }).click();
    await page.getByRole('textbox', {
      name: 'Launch preset',
      exact: true,
    }).click();
    await expect(page.getByRole('option', {
      name: 'Careful launch',
      exact: true,
    })).toBeVisible();
    await page.getByRole('option', {
      name: 'Careful launch',
      exact: true,
    }).click();
    await page.getByRole('button', {
      name: 'Run options',
      exact: true,
    }).click();
    await expect(page.getByLabel('Instructions override', {
      exact: true,
    })).toHaveValue('Preset instructions');
    await expect(page.getByRole('textbox', {
      name: 'Automatic team review',
      exact: true,
    })).toHaveValue('Enabled');
    await expect(page.getByLabel('Reviewer name', {
      exact: true,
    })).toHaveValue('Preset reviewer');
    await page.getByLabel('Instructions override', {
      exact: true,
    }).fill('Edited instructions');
    await page.getByRole('button', {
      name: 'Start run',
      exact: true,
    }).click();
    await expect(page.getByText('Preset run complete.', {
      exact: true,
    }).first()).toBeVisible();
    const task = (await app.tasks.list({})).find((candidate) => candidate.title === 'Preset goal');
    assert.ok(task);
    const runs = await app.runs.list({
      taskId: task.id,
    });
    const latest = runs.at(-1)!;
    const run = (await app.runs.wait({
      id: latest.id,
    }))!;
    assert.equal(run.options?.modelId, modelId);
    assert.equal(run.options?.instructions, 'Edited instructions');
    assert.equal(run.options?.review?.enabled, true);
    assert.equal(run.options?.review?.participants?.length, 1);
    assert.equal(run.options?.review?.participants?.[0].name, 'Preset reviewer');
    assert.equal(run.options?.review?.participants?.[0].instructions, '');
    assert.equal((await app.sessions.get({
      id: run.sessionId,
    }))!.instructions, 'Edited instructions');
    const expectedOptions: PresetOptions = {
      modelId,
      instructions: 'Edited instructions',
      review: {
        enabled: true,
        participants: [
          {
            name: 'Preset reviewer',
            instructions: '',
          },
        ],
      },
    };
    await page.locator('.sidebar').getByRole('button', {
      name: 'Presets',
      exact: true,
    }).click();
    await page.getByRole('button', {
      name: 'Edit',
      exact: true,
    }).click();
    await page.getByRole('dialog').getByRole('textbox', {
      name: 'Preset name',
      exact: true,
    }).fill('Renamed preset');
    await page.getByRole('dialog').getByRole('button', {
      name: 'Save',
      exact: true,
    }).click();
    await expect(page.getByText('Renamed preset', {
      exact: true,
    })).toBeVisible();
    await page.getByRole('button', {
      name: 'Delete',
      exact: true,
    }).click();
    await expect(page.getByText('No saved presets yet', {
      exact: true,
    })).toBeVisible();
    assert.deepEqual(await app.presets.list(), []);
    assert.deepEqual((await app.runs.get({
      id: run.id,
    }))!.options, expectedOptions);
    assert.deepEqual(await app.settings.get(), defaults);
    assert.deepEqual(errors, []);
  },
);
