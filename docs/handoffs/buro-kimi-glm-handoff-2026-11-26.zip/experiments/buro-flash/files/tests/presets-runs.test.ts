import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createApplication } from '../modules/application/create-application.ts';
import type { BackendRequest } from '../modules/engines/backend.ts';
import type { PresetOptions } from '#shared/contracts';

const exec = promisify(execFile);

test('a run copies preset options and later preset edits or deletion leave that run unchanged', async (t) => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'buro-presets-runs-'));
  const source = path.join(directory, 'source');
  await fs.mkdir(source);
  await fs.writeFile(path.join(source, 'README.md'), 'Project');
  await exec('git', ['init', '-q', source]);
  await exec('git', ['add', '.'], {
    cwd: source,
  });
  await exec(
    'git',
    ['-c', 'user.name=Test', '-c', 'user.email=test@example.invalid', 'commit', '-qm', 'Initial'],
    {
      cwd: source,
    },
  );
  const requests: BackendRequest[] = [];
  const app = await createApplication({
    directory: path.join(directory, 'state'),
    transports: [
      {
        id: 'fixture',
        create({ configuration }) {
          return {
            id: configuration.id,
            revision: configuration.revision,
            async complete(request) {
              requests.push(structuredClone({
                ...request,
                executeTool: undefined,
                signal: undefined,
                onProgress: undefined,
                onEvent: undefined,
                onRetry: undefined,
              }) as unknown as BackendRequest);
              return {
                model: 'fixture',
                finish: 'stop',
                message: {
                  role: 'assistant',
                  content: 'Done',
                },
              };
            },
          };
        },
      },
    ],
  });
  t.after(async () => {
    await app.close();
    await fs.rm(directory, {
      recursive: true,
      force: true,
    });
  });
  const model = (
    await app.modelConfigurations.save({
      configuration: {
        name: 'Fixture',
        transport: 'fixture',
        model: 'fixture',
      },
      default: true,
    })
  ).configuration!;
  const project = (
    await app.projects.connect({
      root: source,
    })
  ).project!;
  const task = await app.tasks.create({
    projectId: project.id,
    title: 'Set the project value',
    description: 'Keep the change simple and verify it.',
  });
  await app.settings.update({
    review: {
      enabled: true,
      participants: [
        {
          name: 'Default reviewer',
          instructions: 'Review the work.',
        },
      ],
    },
  });
  const defaults = await app.settings.get();
  const options: PresetOptions = {
    modelId: model.id,
    instructions: '',
    review: {
      enabled: false,
      participants: [
        {
          name: 'Disabled reviewer',
          instructions: 'Should not run.',
        },
      ],
    },
  };
  const saved = await app.presets.save({
    name: 'Disabled review',
    options,
  });
  assert.equal(saved.ok, true);
  const started = await app.runs.start({
    taskId: task.id,
    options: structuredClone(saved.preset!.options),
  });
  assert.equal(started.ok, true);
  const run = (await app.runs.wait({
    id: started.run!.id,
  }))!;
  assert.equal(run.status, 'completed');
  assert.deepEqual(run.options, options);
  assert.equal(
    (await app.sessions.get({
      id: run.sessionId,
    }))!.instructions,
    '',
  );
  assert.equal(run.review, undefined);
  assert.equal(
    (
      await app.sessions.list({
        runId: run.id,
      })
    ).length,
    1,
  );
  assert.equal(requests.some((request) => request.schema !== undefined), false);
  const updated = await app.presets.save({
    id: saved.preset!.id,
    name: 'Renamed review',
    options: {
      modelId: model.id,
      instructions: 'Different instructions',
      review: {
        enabled: true,
        participants: [
          {
            name: 'New reviewer',
            instructions: 'Use a different focus.',
          },
        ],
      },
    },
  });
  assert.equal(updated.ok, true);
  await app.presets.delete({
    id: saved.preset!.id,
  });
  assert.equal(
    await app.presets.get({
      id: saved.preset!.id,
    }),
    undefined,
  );
  assert.deepEqual(
    (await app.runs.get({
      id: run.id,
    }))!.options,
    options,
  );
  assert.deepEqual(await app.settings.get(), defaults);
});
