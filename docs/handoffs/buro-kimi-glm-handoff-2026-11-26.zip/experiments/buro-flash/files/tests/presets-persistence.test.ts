import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createApplication } from '../modules/application/create-application.ts';
import type { Application } from '../modules/application/application.ts';
import type { LaunchPreset } from '#shared/contracts';

test('saved launch presets keep explicit empty and disabled overrides across an application restart', async (t) => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'buro-presets-persistence-'));
  let app: Application | undefined;
  t.after(async () => {
    await app?.close();
    await fs.rm(directory, {
      recursive: true,
      force: true,
    });
  });
  app = await createApplication({
    directory,
  });
  const defaults = await app.settings.get();
  const saved = await app.presets.save({
    name: 'Empty instructions',
    options: {
      instructions: '',
      review: {
        enabled: false,
        participants: [
          {
            name: 'Disabled reviewer',
            instructions: 'Should not run.',
          },
        ],
      },
    },
  });
  assert.equal(saved.ok, true);
  const expected: LaunchPreset = {
    id: saved.preset!.id,
    name: 'Empty instructions',
    options: {
      instructions: '',
      review: {
        enabled: false,
        participants: [
          {
            name: 'Disabled reviewer',
            instructions: 'Should not run.',
          },
        ],
      },
    },
  };
  await app.close();
  app = await createApplication({
    directory,
  });
  assert.deepEqual(await app.presets.list(), [expected]);
  assert.deepEqual(
    await app.presets.get({
      id: expected.id,
    }),
    expected,
  );
  assert.deepEqual(await app.settings.get(), defaults);
});
