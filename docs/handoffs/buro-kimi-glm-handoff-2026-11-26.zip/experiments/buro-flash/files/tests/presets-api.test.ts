import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createApplication } from '../modules/application/create-application.ts';
import { startApiServer } from '../modules/api/server.ts';
import { ApiClient } from '../modules/api/client.ts';
import type { Notification } from '../modules/events/notifications.ts';
import type { LaunchPreset, PresetOptions } from '#shared/contracts';

test('the launch preset API validates external inputs, keeps explicit overrides and reports changes', async (t) => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'buro-presets-api-'));
  const app = await createApplication({
    directory,
  });
  const token = 'test-local-api-token';
  const server = await startApiServer({
    application: app,
    port: 0,
    token,
  });
  const client = new ApiClient({
    url: `ws://127.0.0.1:${server.port}`,
    token,
  });
  t.after(async () => {
    client.close();
    await server.close();
    await app.close();
    await fs.rm(directory, {
      recursive: true,
      force: true,
    });
  });
  const notifications: Notification[] = [];
  client.subscribe((notification) => {
    notifications.push(notification);
  });
  const saveUntrusted = async (params: unknown) =>
    client.call('presets.save', params as { name: string; options: PresetOptions });
  assert.deepEqual(await client.call('presets.list', {}), []);
  assert.equal(
    await client.call('presets.get', {
      id: 'unknown-preset',
    }),
    undefined,
  );
  await assert.rejects(saveUntrusted({
    name: '',
    options: {},
  }));
  await assert.rejects(saveUntrusted({
    name: '   ',
    options: {},
  }));
  await assert.rejects(saveUntrusted({
    name: 'Invalid review',
    options: {
      review: {
        enabled: 'yes',
      },
    },
  }));
  assert.deepEqual(await client.call('presets.list', {}), []);
  const options: PresetOptions = {
    instructions: '',
    review: {
      enabled: false,
      participants: [
        {
          name: 'Disabled reviewer',
          instructions: 'Should not run.',
        },
      ],
    },
  };
  const created = await client.call('presets.save', {
    name: 'Careful launch',
    options,
  });
  assert.equal(created.ok, true);
  const preset = created.preset!;
  assert.ok(preset.id.length > 0);
  assert.equal(preset.name, 'Careful launch');
  assert.deepEqual(preset.options, options);
  assert.deepEqual(
    await client.call('presets.get', {
      id: preset.id,
    }),
    preset,
  );
  const updatedOptions: PresetOptions = {
    modelId: 'any-model',
    instructions: 'Focused instructions',
  };
  const updated = await client.call('presets.save', {
    id: preset.id,
    name: 'Renamed launch',
    options: updatedOptions,
  });
  assert.equal(updated.ok, true);
  assert.equal(updated.preset!.id, preset.id);
  assert.deepEqual(updated.preset!.options, updatedOptions);
  const listed = await client.call('presets.list', {});
  assert.equal(listed.length, 1);
  assert.equal(listed[0].name, 'Renamed launch');
  const missing = await client.call('presets.save', {
    id: 'missing-preset',
    name: 'Missing target',
    options: {},
  });
  assert.equal(missing.ok, false);
  assert.equal(typeof missing.error, 'string');
  assert.equal((await client.call('presets.list', {})).length, 1);
  const second = (await client.call('presets.save', {
    name: 'Second launch',
    options: {},
  })).preset!;
  await client.call('presets.delete', {
    id: preset.id,
  });
  assert.equal(
    await client.call('presets.get', {
      id: preset.id,
    }),
    undefined,
  );
  assert.deepEqual(
    await client.call('presets.get', {
      id: second.id,
    }),
    second,
  );
  const savedIds = notifications
    .filter((notification) => notification.type === 'preset.saved')
    .map((notification) => (notification.data as LaunchPreset).id);
  const deletedIds = notifications
    .filter((notification) => notification.type === 'preset.deleted')
    .map((notification) => (notification.data as LaunchPreset).id);
  assert.ok(savedIds.includes(second.id));
  assert.deepEqual(deletedIds, [preset.id]);
  const callerOptions: PresetOptions = {
    instructions: '',
    review: {
      enabled: false,
      participants: [
        {
          name: 'Caller reviewer',
          instructions: 'Original caller instructions.',
        },
      ],
    },
  };
  const saved = await app.presets.save({
    name: 'Caller-owned options',
    options: callerOptions,
  });
  assert.equal(saved.ok, true);
  callerOptions.instructions = 'Mutated caller instructions';
  callerOptions.review!.enabled = true;
  callerOptions.review!.participants![0].name = 'Mutated reviewer';
  callerOptions.review!.participants![0].instructions = 'Mutated reviewer instructions';
  assert.deepEqual(saved.preset!.options, {
    instructions: '',
    review: {
      enabled: false,
      participants: [
        {
          name: 'Caller reviewer',
          instructions: 'Original caller instructions.',
        },
      ],
    },
  });
  const detached = (await app.presets.get({
    id: saved.preset!.id,
  }))!;
  assert.equal(detached.name, 'Caller-owned options');
  assert.deepEqual(detached.options, {
    instructions: '',
    review: {
      enabled: false,
      participants: [
        {
          name: 'Caller reviewer',
          instructions: 'Original caller instructions.',
        },
      ],
    },
  });
  assert.equal(detached.options.instructions, '');
  assert.equal(detached.options.review!.participants![0].name, 'Caller reviewer');
  assert.equal(detached.options.review!.participants![0].instructions, 'Original caller instructions.');
});
