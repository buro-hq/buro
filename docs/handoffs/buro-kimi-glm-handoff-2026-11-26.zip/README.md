# Buro handoff archive

Start with buro-context-for-kimi-glm.md. For a source-grounded second opinion, then read buro-source-excerpts-for-kimi-glm.md.

current-runtime/ contains selected main-runtime files from 8d6fb1f; this is a context/source package, not a complete installable repository. experiments/ contains separate final feature implementations based on 7738a09, full patches and selected independent domain evidence. These experimental files are not the current product tree. A deleted file is represented in its patch and manifest. review-profiles/ contains all three exact assignments. task/ contains the exact large assignment.

Do not paste every source file at once into a limited context window. Read/search only the files needed for the current question. If the chat cannot unpack archives, attach the two Markdown files separately, then supply individual requested files.

Credentials, raw model transcripts, private reasoning, private connection databases and host network configuration are excluded. This archive is for analysis; it does not authorize another paid benchmark.
